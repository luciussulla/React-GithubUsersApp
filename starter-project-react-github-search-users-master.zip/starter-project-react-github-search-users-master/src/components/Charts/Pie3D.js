import React from 'react';

const Pie3D = () => {
  return <div>chart</div>;
};

export default Pie3D;
