import React from 'react';

const Bar3D = () => {
  return <div>chart</div>;
};

export default Bar3D;
