import React from 'react';

const Doughnut2d = () => {
  return <div>chart</div>;
};

export default Doughnut2d;
