import React from 'react';

const Column3D = () => {
  return <div>chart</div>;
};

export default Column3D;
