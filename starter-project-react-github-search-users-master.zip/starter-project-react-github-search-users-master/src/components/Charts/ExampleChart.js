import React from 'react';

const ExampleChart = () => {
  return <div>chart</div>;
};

export default ExampleChart;
